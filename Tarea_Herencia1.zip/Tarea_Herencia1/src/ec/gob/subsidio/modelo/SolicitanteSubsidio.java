package ec.gob.subsidio.modelo;

public class SolicitanteSubsidio {

    private String nombreCompleto;
    private String cedula;
    private double ingresosMensuales;
    private int cantidadVehiculos;
    private boolean viveEnEcuador;

    public SolicitanteSubsidio(String nombreCompleto, String cedula,double ingresosMensuales, int cantidadVehiculos, boolean viveEnEcuador){

        this.nombreCompleto = nombreCompleto;
        this.cedula = cedula;
        setIngresosMensuales(ingresosMensuales);
        setCantidadVehiculos(cantidadVehiculos);
        this.viveEnEcuador = viveEnEcuador;
    }

    public static void mostrarReglasSubsidio(){

        System.out.println("==== Reglas para obtener el subsidio ====");
        System.out.println("1. Tener ingresos mensuales menores o iguales a $1,200.");
        System.out.println("2. No poseer más de un vehículo registrado.");
        System.out.println("3. Tener residencia en Ecuador.");
        System.out.println("=========================================");
    }

    public String getNombreCompleto(){
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto){
        this.nombreCompleto = nombreCompleto;
    }

    public String getCedula(){
        return cedula;
    }

    public void setCedula(String cedula){
        this.cedula = cedula;
    }

    public double getIngresosMensuales(){
        return ingresosMensuales;
    }

    public void setIngresosMensuales(double ingresosMensuales){

        if(ingresosMensuales >= 470){
            this.ingresosMensuales = ingresosMensuales;
        }else{
            System.out.println("Ingreso no valido, se asigna 470");
            this.ingresosMensuales = 470;
        }
    }

    public int getCantidadVehiculos(){
        return cantidadVehiculos;
    }

    public void setCantidadVehiculos(int cantidadVehiculos){

        if(cantidadVehiculos >=0){
            this.cantidadVehiculos = cantidadVehiculos;
        }else{
            System.out.println("Cantidad no valida, se asigna 0");
            this.cantidadVehiculos = 0;
        }
    }

    public boolean isViveEnEcuador(){
        return viveEnEcuador;
    }

    public void setViveEnEcuador(boolean viveEnEcuador){
        this.viveEnEcuador = viveEnEcuador;
    }

    public boolean subsidioAprobado(){

        if(ingresosMensuales <=1200 && cantidadVehiculos <=1 && viveEnEcuador){

            return true;
        }

        return false;
    }

    public void generarResultado(){

        if(subsidioAprobado()){
            System.out.println("Subsidio aprobado");
        }
        else{

            System.out.println("Subsidio rechazado");

            if(ingresosMensuales >1200){
                System.out.println("Motivo: ingresos exceden limite");
            }

            if(cantidadVehiculos >1){
                System.out.println("Motivo: posee mas de un vehiculo");
            }

            if(!viveEnEcuador){
                System.out.println("Motivo: no reside en Ecuador");
            }

        }

    }

    public double calcularConsumoMensual(){

        double kmMensuales = 800;
        return kmMensuales/40;
    }

    public double calcularConsumoMensual(double kmExtra){

        double kmMensuales = 800 + kmExtra;
        return kmMensuales/40;
    }

    @Override
    public String toString(){

        return "Nombre: " + nombreCompleto +
                "\nCedula: " + cedula +
                "\nIngresos: " + ingresosMensuales +
                "\nVehiculos: " + cantidadVehiculos +
                "\nVive en Ecuador: " + viveEnEcuador;
    }

}