import java.util.Scanner;
import ec.gob.subsidio.modelo.SolicitanteSubsidio;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        SolicitanteSubsidio.mostrarReglasSubsidio();

        System.out.print("\nIngrese su nombre completo: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese su cédula: ");
        String cedula = sc.nextLine();

        System.out.print("Ingrese sus ingresos mensuales: ");
        double ingresos = sc.nextDouble();

        System.out.print("Ingrese la cantidad de vehículos registrados: ");
        int vehiculos = sc.nextInt();

        System.out.print("¿Vive en Ecuador? (true/false): ");
        boolean vive = sc.nextBoolean();

        SolicitanteSubsidio solicitante = new SolicitanteSubsidio(nombre, cedula, ingresos, vehiculos, vive);

        System.out.println("\nDatos del solicitante");
        System.out.println(solicitante);

        System.out.println("\nResultado:");
        solicitante.generarResultado();

        double consumo1 = solicitante.calcularConsumoMensual();
        double consumo2 = solicitante.calcularConsumoMensual(300);

        System.out.println("\nConsumo normal: " + consumo1 + " galones");

        System.out.println("Consumo con km extra: " + consumo2 + " galones");

    }
}